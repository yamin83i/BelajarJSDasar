for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (y==1){
        document.write("0")
        }else if(y==5){
        document.write("0")
        }
        else if (x==1){
        document.write("0")
        }
        else if (y==3){
         document.write("0")
        }
        else{
        document.write("- ") 
        }
    }document.write("<br>")
}
document.write("<br>")



for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (x==1){
        document.write("0")
        }else if(x==5){
        document.write("0")
        }else if (x==2 && y==2){
        document.write("0")
        }else if (x==3 && y==3){
        document.write("0")
        }else if (x==4 && y==4){
        document.write("0")
         }else{
        document.write("- ") 
        }
    }document.write("<br>")
}
document.write("<br>")



for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (y==1){
        document.write("0")
        }else if (x==1){
        document.write("0")
        }else if(y==5){
        document.write("0")
        }else if (x==5&&y==4){
        document.write("0")
        }else if (y==3&&x==3||y==3&&x==4||y==3&&x==5 ){
        document.write("0")
        }else{
        document.write("- ") 
        }
    }  document.write("<br>")
}
document.write("<br>")


for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (x==1){
        document.write("0")
        }else if(y==5){
        document.write("0")
        }else{
        document.write("- ") 
        }
    }document.write("<br>")
}
document.write("<br>")




for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (x==3){
        document.write("0")
        }else{
        document.write("- ") 
        }
    }document.write("<br>")
}
document.write("<br>")
    



for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++){
        if (y==1){
        document.write("0")
        }else if (y==5){
        document.write("0")
        }else if(y==3){
        document.write("0")
        }else if (x==1&&y==2){
        document.write("0")
        }else if (y==4&&x==5){
        document.write("0")
        }else{
        document.write("- ") 
        }   
    } document.write("<br>")
}
document.write("<br>")



for (var y=1; y<=5; y++){
    for (var x=1; x<=5; x++)
        if (y==3 || x==5 ||x==1 )
        document.write("0")
         else
                
        document.write("- ")
                
    document.write("<br>")
}




